package com.miaivideo.app;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class RadioPlaybackService extends Service {
    public static final String ACTION_PLAY="com.miaivideo.app.RADIO_PLAY";
    public static final String ACTION_STOP="com.miaivideo.app.RADIO_STOP";
    private static final String CHANNEL="ia_a13j0_radio";
    private MediaPlayer player;

    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?ACTION_PLAY:intent.getAction();
        if(ACTION_STOP.equals(action)){getSharedPreferences("mi_ai_video_private",0).edit().putBoolean("radio_playing",false).apply();stopPlayback();stopForeground(true);stopSelf();return START_NOT_STICKY;}
        startForeground(1201,notification("Conectando con la emisora…"));
        if(player==null)startPlayback();
        return START_STICKY;
    }
    private void startPlayback(){
        try{
            player=new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource("https://uk19freenew.listen2myradio.com/live.mp3?typeportmount=s1_27343_stream_371987632");
            player.setOnPreparedListener(mp->{mp.start();updateNotification("Reproduciendo en segundo plano");});
            player.setOnErrorListener((mp,w,e)->{stopPlayback();stopForeground(true);stopSelf();return true;});
            player.prepareAsync();
        }catch(Exception e){getSharedPreferences("mi_ai_video_private",0).edit().putBoolean("radio_playing",false).apply();stopPlayback();stopForeground(true);stopSelf();}
    }
    private void stopPlayback(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Radio 12 Estéreo",NotificationManager.IMPORTANCE_LOW);c.setDescription("Reproducción de radio en segundo plano");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(String text){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Intent stop=new Intent(this,RadioPlaybackService.class);stop.setAction(ACTION_STOP);
        PendingIntent pi=PendingIntent.getService(this,1202,stop,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        return b.setContentTitle("++IA A13J0++ · Radio").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Detener",pi).build();
    }
    private void updateNotification(String text){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1201,notification(text));}
    @Override public void onDestroy(){stopPlayback();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
