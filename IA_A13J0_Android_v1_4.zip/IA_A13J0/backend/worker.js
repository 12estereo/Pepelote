// Cloudflare Worker: emite credenciales temporales para el módulo de voz de ++IA A13J0++.
// Configura OPENAI_API_KEY como Secret en Cloudflare Workers. Nunca la pongas en el APK.
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store"
};
export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin");
    if (origin && origin !== "https://appassets.androidplatform.net") return new Response("Origen no autorizado", { status: 403, headers: cors });
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response(JSON.stringify({ error: "Método no permitido" }), { status: 405, headers: { ...cors, "Content-Type": "application/json" } });
    if (!env.OPENAI_API_KEY) return new Response(JSON.stringify({ error: "El servidor aún no tiene configurada su clave privada." }), { status: 503, headers: { ...cors, "Content-Type": "application/json" } });
    try {
      const body = await request.json();
      const allowedVoices = new Set(["marin", "cedar"]);
      const voice = allowedVoices.has(body.voice) ? body.voice : "marin";
      const mode = body.mode === "push" ? "push" : "continuous";
      const session = {
        type: "realtime",
        model: "gpt-realtime-2.1",
        instructions: "Eres ++A13J0++, un asistente amable, claro y útil. Habla en español latinoamericano natural, salvo que la persona solicite otro idioma. Responde de forma conversacional y no menciones proveedores ni nombres técnicos del motor.",
        audio: {
          input: {
            noise_reduction: { type: "near_field" },
            turn_detection: mode === "continuous" ? { type: "server_vad", threshold: 0.5, prefix_padding_ms: 300, silence_duration_ms: 500 } : null
          },
          output: { voice }
        },
        output_modalities: ["audio"]
      };
      const upstream = await fetch("https://api.openai.com/v1/realtime/client_secrets", {
        method: "POST",
        headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ expires_after: { anchor: "created_at", seconds: 600 }, session })
      });
      const data = await upstream.json();
      if (!upstream.ok) return new Response(JSON.stringify({ error: data.error?.message || "No se pudo crear la credencial temporal." }), { status: upstream.status, headers: { ...cors, "Content-Type": "application/json" } });
      return new Response(JSON.stringify({ value: data.value, expires_at: data.expires_at }), { headers: { ...cors, "Content-Type": "application/json" } });
    } catch (error) {
      return new Response(JSON.stringify({ error: "Solicitud inválida o error al crear la sesión." }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
    }
  }
};
